   <!-- Footer -->
    <footer class="bg-dark text-white py-4">
        <div class="container">
            <div class="row ms-auto">
                <div class="col">
                    <h4>Kontak Saya</h4>
                    <ul class="list-unstyled">
                        <li>Email: muhammadlepii@gmail.com</li>
                        <li>Phone: 081333499898</li>
                    </ul>
                </div>
                <div class="col">
                    <h4>Links</h4>
                    <ul class="list-unstyled">
                        <li><a href="/">Home</a></li>
                        <li><a href="about">About</a></li>
                        <li><a href="contact">Contact</a></li>
                    </ul>
                </div>
                <div class="col">
                    <h4>Follow Saya</h4>
                    <ul class="list-unstyled">
                        <li><a href="#"><i class="fab fa-facebook"></i> Facebook</a></li>
                        <li><a href="#"><i class="fab fa-twitter"></i> Twitter</a></li>
                        <li><a href="#"><i class="fab fa-instagram"></i> Instagram</a></li>
                    </ul>
                </div>
            </div>
        </div>
        <div class="text-center">
            <p class="small mt-2 mb-0">Made With Love | Muhammad Lefi Rachmad</p>
        </div>
    </footer>

<?php /**PATH D:\laragon\www\laravelleps\resources\views/layout/footer.blade.php ENDPATH**/ ?>