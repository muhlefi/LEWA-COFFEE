<!-- resources/views/dashboard/index.blade.php -->

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Lefi | Dashboard</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
    <style>
        .truncate {
            max-width: 18px;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }

        html, body {
            height: 100%;
            margin: 0;
            padding: 0;
        }

        .container {
            min-height: 100%;
            display: flex;
            flex-direction: column;
        }

        .content {
            flex: 1;
        }
    </style>
</head>

<body>
    <div class="container mt-5">
        <h2 class="text-center mb-4">Dashboard Pemesanan</h2>
        <div class="content">
            <table class="table table-bordered" style="margin: 0 auto;">
                <thead class="thead-dark">
                    <tr>
                        <th>Nama</th>
                        <th>Email</th>
                        <th>Nomor HP</th>
                        <th>Menu</th>
                        <th>Jumlah Pesanan</th>
                        <th>Alamat</th>
                        <th>Pesan</th>
                        <th>Waktu Order</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($order->nama); ?></td>
                            <td><?php echo e($order->email); ?></td>
                            <td><?php echo e($order->nomor_hp); ?></td>
                            <td><?php echo e($order->menu); ?></td>
                            <td><?php echo e($order->jumlah_pesanan); ?></td>
                            <td class="truncate"><?php echo e($order->alamat); ?></td>
                            <td class="truncate"><?php echo e($order->pesan); ?></td>
                            <td><?php echo e($order->created_at); ?></td>
                            <td>
                                <a href="<?php echo e(route('edit', ['id' => $order->id])); ?>" class="btn btn-success">Edit</a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
    <!-- Footer -->
    <footer class="bg-dark text-white py-4">
        <div class="container">
            <div class="row">
                <div class="col">
                    <h4>Kontak Saya</h4>
                    <ul class="list-unstyled">
                        <li>Email: muhammadlepii@gmail.com</li>
                        <li>Phone: 081333499898</li>
                    </ul>
                </div>
                <div class="col">
                    <h4>Links</h4>
                    <ul class="list-unstyled">
                        <li><a href="/">Home</a></li>
                        <li><a href="#aboutme">About me</a></li>
                        <li><a href="contact">Contact</a></li>
                    </ul>
                </div>
                <div class="col">
                    <h4>Follow Saya</h4>
                    <ul class="list-unstyled">
                        <li><a href="#"><i class="fab fa-facebook"></i> Facebook</a></li>
                        <li><a href="#"><i class="fab fa-twitter"></i> Twitter</a></li>
                        <li><a href="#"><i class="fab fa-instagram"></i> Instagram</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </footer>
    <!-- Bootstrap JS and Popper.js -->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
</body>

</html>
<?php /**PATH D:\laragon\www\laravelleps\resources\views/dashboard.blade.php ENDPATH**/ ?>