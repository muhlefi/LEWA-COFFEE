

<!-- Navbar -->
<nav class="navbar navbar-expand-lg bg-primary shadow p-3 fixed-top" data-bs-theme="dark">
    <div class="container-fluid">
        <a class="navbar-brand" href="/">Lefi Website</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavAltMarkup"
            aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
            <div class="navbar-nav ms-auto">
                <a class="nav-link <?php echo $__env->yieldContent('navbarhome'); ?>" aria-current="page" href="/">Home</a>
                <a class="nav-link <?php echo $__env->yieldContent('navbaraboutme'); ?>" href="#aboutme">About Me</a>
                <a class="nav-link <?php echo $__env->yieldContent('navbarproject'); ?>" href="#project">Produk</a>
                <a class="nav-link <?php echo $__env->yieldContent('navbarcontact'); ?>" href="contact">Order Now</a>

                <?php if(auth()->guard()->check()): ?>
                <!-- Tampilkan tombol logout jika pengguna sudah login -->
                <form method="POST" action="<?php echo e(route('logout')); ?>">
                    <?php echo csrf_field(); ?>
                    <button type="submit" class="nav-link btn btn-link">Logout</button>
                </form>
            <?php else: ?>
                <a class="nav-link" href="<?php echo e(route('login')); ?>">Log in</a>
            <?php endif; ?>
        </div>
    </div>
</nav>
<?php /**PATH D:\laragon\www\laravelleps\resources\views/layout/navbar.blade.php ENDPATH**/ ?>