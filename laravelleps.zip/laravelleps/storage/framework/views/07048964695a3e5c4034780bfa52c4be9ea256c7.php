

<?php $__env->startSection('navbarproject'); ?>
    active
<?php $__env->stopSection(); ?>

<?php $__env->startSection('header'); ?>
    <div class="col text-center">
        <h3 class="pb-4 mb-3 fst-italic border-bottom">
            From the Skansa
        </h3>

        <article class="blog-post">
            <h2 class="display-5 link-body-emphasis mb-1">Membuat Situs Web "Wonderful Pasuruan"</h2>
            <p class="blog-post-meta">September 16, 2023 by <a href="/">Muhammad Lefi Rachmad</a></p>

            <p>Tujuan dari tugas akhir ini adalah untuk membuat sebuah situs web yang menggambarkan keindahan dan daya tarik
                Kota Pasuruan. Situs web ini akan berfungsi sebagai sumber informasi yang berguna untuk penduduk setempat
                dan wisatawan yang ingin mengenal lebih jauh tentang Kota Pasuruan.</p>
            <hr>
            <p>Tugas akhir ini akan mencakup pembuatan situs web yang mencakup informasi tentang tempat wisata, budaya,
                sejarah, kuliner, acara, dan aktivitas di Pasuruan. Situs web ini akan dirancang dengan tampilan yang
                menarik dan responsif, sehingga dapat diakses dengan baik dari perangkat berbagai ukuran.</p>
            <h2>Quote</h2>
            <blockquote class="blockquote">
                <p>Semua akan bisa kalau terbiasa.</p>
            </blockquote>
            <p>Dalam metaverse, pengguna dapat membuat avatar digital yang mewakili diri mereka sendiri dan menjelajahi
                dunia maya yang beragam. Mereka dapat berinteraksi dengan pengguna lain, membangun properti digital, bermain
                game, bekerja, dan bahkan menghadiri acara sosial dalam lingkungan virtual. Ini membuka peluang yang tak
                terbatas untuk hiburan, pendidikan, kolaborasi bisnis, dan banyak lagi.</p>
            <p>Namun, ada juga tantangan dan pertanyaan etis yang muncul seiring dengan perkembangan metaverse. Misalnya,
                tentang privasi pengguna, keamanan data, dan dampak psikologis dari interaksi yang terus-menerus dalam dunia
                maya.</p>
            <p>Dengan teknologi terus berkembang, masa depan metaverse masih belum pasti, tetapi satu hal yang pasti, ia
                akan memainkan peran penting dalam bentuk dunia digital yang akan datang.</p>
            <h4 class="py-3">Halaman yang saya buat berisi berikut ini :</h4>
            <ol style="text-align: left">
                <li> <b>Halaman Beranda:</b> Menampilkan gambaran umum tentang Kota Pasuruan dan fitur terbaru.</li>
                <li> <b>Halaman Tempat Wisata:</b> Menampilkan informasi tentang tempat-tempat wisata terkenal beserta
                    deskripsi dan gambar.</li>
                <li> <b>Kontak dan Informasi Tambahan</b> Informasi kontak dan panduan untuk wisatawan.
                    Teknologi yang Digunakan: Untuk membuat situs web "Wonderful Pasuruan," Anda dapat menggunakan teknologi
                    seperti HTML, CSS, JavaScript, dan mungkin juga mempertimbangkan kerangka kerja web seperti Bootstrap
                    untuk mempercepat pengembangan. Juga, Anda akan memerlukan penyimpanan gambar dan data yang dapat
                    diakses dari server web.</li>
            </ol>
        </article>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\laravelleps\resources\views/tugasakhir.blade.php ENDPATH**/ ?>