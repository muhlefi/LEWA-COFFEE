


<?php $__env->startSection('navbarproject'); ?>
    active
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout/navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layout/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\laravelleps\resources\views/project.blade.php ENDPATH**/ ?>